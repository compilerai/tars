//
// immer: immutable data structures for C++
// Copyright (C) 2016, 2017, 2018 Juan Pedro Bolivar Puente
//
// This software is distributed under the Boost Software License, Version 1.0.
// See accompanying file LICENSE or copy at http://boost.org/LICENSE_1_0.txt
//

#include <immer/set.hpp>
#include <immer/set_transient.hpp>

#define SET_T ::immer::set
#define SET_TRANSIENT_T ::immer::set_transient

#include "generic.ipp"
